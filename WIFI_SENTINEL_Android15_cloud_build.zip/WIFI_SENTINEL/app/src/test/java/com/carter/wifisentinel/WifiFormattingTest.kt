package com.carter.wifisentinel

import com.carter.wifisentinel.data.WifiFormatting
import org.junit.Assert.assertEquals
import org.junit.Test

class WifiFormattingTest {
    @Test fun mapsCommonTwoGhzChannels() {
        assertEquals(1, WifiFormatting.channelForFrequency(2412))
        assertEquals(6, WifiFormatting.channelForFrequency(2437))
        assertEquals(11, WifiFormatting.channelForFrequency(2462))
    }

    @Test fun mapsChannelFourteen() {
        assertEquals(14, WifiFormatting.channelForFrequency(2484))
    }

    @Test fun mapsFiveGhzChannel() {
        assertEquals(36, WifiFormatting.channelForFrequency(5180))
    }

    @Test fun mapsSixGhzChannel() {
        assertEquals(1, WifiFormatting.channelForFrequency(5955))
    }

    @Test fun unknownFrequencyReturnsMinusOne() {
        assertEquals(-1, WifiFormatting.channelForFrequency(1234))
    }

    @Test fun detectsWpa3BeforeWpa2() {
        assertEquals("WPA3", WifiFormatting.securityFromCapabilities("[WPA2-PSK][SAE]"))
    }

    @Test fun detectsOpenNetwork() {
        assertEquals("Open / unknown", WifiFormatting.securityFromCapabilities(""))
    }
}
