package com.carter.wifisentinel.security

import java.security.SecureRandom

object PassphraseGenerator {
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%+-_"
    private val random = SecureRandom()

    fun generate(length: Int = 20): String {
        require(length in 12..64) { "Length must be between 12 and 64 characters" }
        return buildString(length) {
            repeat(length) { append(ALPHABET[random.nextInt(ALPHABET.length)]) }
        }
    }
}
