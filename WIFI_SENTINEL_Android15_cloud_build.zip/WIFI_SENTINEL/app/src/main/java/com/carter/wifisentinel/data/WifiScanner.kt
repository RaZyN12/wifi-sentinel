package com.carter.wifisentinel.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat

class WifiScanner(context: Context) {
    private val appContext = context.applicationContext
    private val wifiManager =
        appContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    fun hasScanPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun startScan(): Boolean {
        if (!hasScanPermission()) return false
        return try { wifiManager.startScan() } catch (_: SecurityException) { false }
    }

    fun readResults(): List<WifiNetwork> {
        if (!hasScanPermission()) return emptyList()
        return try {
            wifiManager.scanResults.orEmpty().map { result ->
                val ssid = result.SSID?.takeIf { it.isNotBlank() } ?: "<hidden SSID>"
                WifiNetwork(
                    ssid = ssid,
                    bssid = result.BSSID ?: "Unavailable",
                    frequencyMhz = result.frequency,
                    rssiDbm = result.level,
                    security = WifiFormatting.securityFromCapabilities(result.capabilities.orEmpty()),
                    channel = WifiFormatting.channelForFrequency(result.frequency)
                )
            }.sortedByDescending { it.rssiDbm }
        } catch (_: SecurityException) {
            emptyList()
        }
    }

    fun wifiEnabled(): Boolean = try { wifiManager.isWifiEnabled } catch (_: SecurityException) { false }
}
