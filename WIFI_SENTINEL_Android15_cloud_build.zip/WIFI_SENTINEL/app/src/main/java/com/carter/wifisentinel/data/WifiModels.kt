package com.carter.wifisentinel.data

data class WifiNetwork(
    val ssid: String,
    val bssid: String,
    val frequencyMhz: Int,
    val rssiDbm: Int,
    val security: String,
    val channel: Int
)

object WifiFormatting {
    fun channelForFrequency(frequency: Int): Int = when (frequency) {
        in 2412..2472 -> (frequency - 2407) / 5
        2484 -> 14
        in 5000..5895 -> (frequency - 5000) / 5
        in 5955..7115 -> (frequency - 5950) / 5
        else -> -1
    }

    fun securityFromCapabilities(capabilities: String): String {
        val c = capabilities.uppercase()
        return when {
            "WPA3" in c || "SAE" in c -> "WPA3"
            "WPA2" in c -> "WPA2"
            "WPA" in c -> "WPA"
            "WEP" in c -> "WEP (legacy)"
            "OWE" in c -> "Enhanced Open (OWE)"
            else -> "Open / unknown"
        }
    }
}
