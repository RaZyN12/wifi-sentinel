package com.carter.wifisentinel.ui

import android.app.Application
import android.content.IntentFilter
import android.net.wifi.WifiManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.carter.wifisentinel.data.WifiNetwork
import com.carter.wifisentinel.data.WifiScanner
import com.carter.wifisentinel.security.PassphraseGenerator
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SentinelState(
    val networks: List<WifiNetwork> = emptyList(),
    val status: String = "Grant Location permission to scan nearby networks.",
    val scanning: Boolean = false,
    val generatedPassphrase: String = ""
)

class SentinelViewModel(application: Application) : AndroidViewModel(application) {
    private val scanner = WifiScanner(application)
    private val _state = MutableStateFlow(SentinelState())
    val state = _state.asStateFlow()

    fun refreshResults() {
        val results = scanner.readResults()
        _state.value = _state.value.copy(
            networks = results,
            status = if (results.isEmpty()) "No results yet. Enable Wi-Fi and Location, then scan again."
                     else "${results.size} access point(s) found. Results may be cached by Android."
        )
    }

    fun scan() {
        if (!scanner.hasScanPermission()) {
            _state.value = _state.value.copy(status = "Location permission is required for scan results.")
            return
        }
        if (!scanner.wifiEnabled()) {
            _state.value = _state.value.copy(status = "Turn on Wi-Fi before scanning.")
            return
        }
        _state.value = _state.value.copy(scanning = true, status = "Requesting Wi-Fi scan…")
        val accepted = scanner.startScan()
        viewModelScope.launch {
            delay(2500)
            refreshResults()
            _state.value = _state.value.copy(
                scanning = false,
                status = if (accepted) _state.value.status else
                    "Android did not start a fresh scan; showing available cached results if any. Scans are system-throttled."
            )
        }
    }

    fun generatePassphrase() {
        _state.value = _state.value.copy(generatedPassphrase = PassphraseGenerator.generate())
    }
}
