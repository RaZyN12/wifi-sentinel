package com.carter.wifisentinel

import com.carter.wifisentinel.security.PassphraseGenerator
import org.junit.Assert.*
import org.junit.Test

class PassphraseGeneratorTest {
    @Test fun defaultLengthIsTwenty() {
        assertEquals(20, PassphraseGenerator.generate().length)
    }

    @Test fun requestedLengthIsHonored() {
        assertEquals(32, PassphraseGenerator.generate(32).length)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsTooShortLength() {
        PassphraseGenerator.generate(8)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsTooLongLength() {
        PassphraseGenerator.generate(65)
    }

    @Test fun generatedCharactersAreFromApprovedAlphabet() {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%+-_".toSet()
        assertTrue(PassphraseGenerator.generate(40).all { it in alphabet })
    }
}
