package com.carter.wifisentinel.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Crimson = Color(0xFFFF3B4E)
private val Background = Color(0xFF09090C)
private val Surface = Color(0xFF17171D)

@Composable
fun SentinelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Crimson,
            secondary = Color(0xFFFF7885),
            background = Background,
            surface = Surface,
            onPrimary = Color.White,
            onBackground = Color(0xFFF4F4F6),
            onSurface = Color(0xFFF4F4F6)
        ),
        content = content
    )
}
