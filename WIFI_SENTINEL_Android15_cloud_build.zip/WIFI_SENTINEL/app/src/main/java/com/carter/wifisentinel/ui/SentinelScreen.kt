package com.carter.wifisentinel.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.carter.wifisentinel.data.WifiNetwork
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SentinelScreen(viewModel: SentinelViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true) viewModel.scan()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("WIFI SENTINEL", fontWeight = FontWeight.Black)
                        Text("LOCAL NETWORK SECURITY TOOLKIT", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("NETWORK RADAR", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(state.status, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall)
                        Button(
                            onClick = {
                                permissionLauncher.launch(
                                    if (Build.VERSION.SDK_INT >= 33)
                                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.NEARBY_WIFI_DEVICES)
                                    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (state.scanning) "SCANNING…" else "SCAN NEARBY WI-FI")
                        }
                        OutlinedButton(onClick = viewModel::refreshResults, modifier = Modifier.fillMaxWidth()) {
                            Text("LOAD AVAILABLE RESULTS")
                        }
                    }
                }
            }
            item {
                Text("ACCESS POINTS (${state.networks.size})", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
            }
            if (state.networks.isEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Text("No scan results available yet. Grant permission, enable Wi-Fi and Location services, then scan.",
                            Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else {
                items(state.networks, key = { it.bssid + it.frequencyMhz }) { network ->
                    NetworkCard(network)
                }
            }
            item {
                PassphraseCard(
                    passphrase = state.generatedPassphrase,
                    onGenerate = viewModel::generatePassphrase
                )
            }
            item {
                Text("Privacy: scan data stays on this device and is not uploaded.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun NetworkCard(network: WifiNetwork) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Wifi, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(network.ssid, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${network.rssiDbm} dBm", color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.labelMedium)
            }
            Text("Security: ${network.security}", style = MaterialTheme.typography.bodySmall)
            Text("Channel ${network.channel.takeIf { it > 0 }?.toString() ?: "unknown"} · ${network.frequencyMhz} MHz",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("BSSID: ${network.bssid}", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PassphraseCard(passphrase: String, onGenerate: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("STRONG PASSPHRASE", fontWeight = FontWeight.Bold)
            }
            Text(if (passphrase.isBlank()) "Generate a random passphrase for a network you administer."
                else passphrase, style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth()) {
                Text("GENERATE LOCALLY")
            }
        }
    }
}
