package com.carter.wifisentinel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.carter.wifisentinel.ui.SentinelScreen
import com.carter.wifisentinel.ui.SentinelViewModel
import com.carter.wifisentinel.ui.theme.SentinelTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SentinelTheme {
                val vm: SentinelViewModel = viewModel()
                SentinelScreen(viewModel = vm)
            }
        }
    }
}
